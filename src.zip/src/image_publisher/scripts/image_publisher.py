# -*- coding: utf-8 -*-


# !/ usr / bin / env python
import rospy
from sensor_msgs . msg import Image
from cv_bridge import CvBridge
import cv2
import glob
def image_publisher () :
    rospy . init_node ( ' image_publisher ' , anonymous = True )
    pub = rospy . Publisher ( '/ camera / image_raw ' , Image , queue_size =10)
    rate = rospy . Rate (1) # publish images
    bridge = CvBridge ()
    
    # Load images from the dataset
    image_files = sorted ( glob . glob ( '/ home / user / calibration_dataset /*. png ') )
    # UPDATE THE PATH AND FILE TYPE HERE
    
    if not image_files :
        rospy . logerr ( " No images found in the dataset directory ! " )
        return
    rospy . loginfo ( " Publishing images for calibration ... " )
    for image_file in image_files :
        img = cv2 . imread ( image_file )
        if img is None :
            rospy . logwarn ( f" Failed to load image : { image_file } " )
            continue
        
        # Convert and publish the image
        img_msg = bridge . cv2_to_imgmsg ( img , encoding = " bgr8 " )
        pub . publish ( img_msg )
        rate . sleep ()
        
    rospy . loginfo ( " Finished publishing images . " )
    rospy . signal_shutdown ( " Dataset exhausted . " )
if __name__ == ' __main__' :
    try :
        image_publisher ()
    except rospy . ROSInterruptException :
        pass
