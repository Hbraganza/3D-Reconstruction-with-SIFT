#!/usr/bin/env python3
import rospy
import moveit_commander
import sys
 
rospy.init_node("move_group_demo", anonymous=True)
moveit_commander.roscpp_initialize(sys.argv)
robot = moveit_commander.RobotCommander()
scene = moveit_commander.PlanningSceneInterface()
group = moveit_commander.MoveGroupCommander("manipulator")
 
pose_goal = group.get_current_pose().pose
# print(pose_goal)
pose_goal.position.x = 0.4090885407833892
pose_goal.position.y = 0.11946863629879641
pose_goal.position.z = 0.5028694270430667
pose_goal.orientation.x = -0.8667170397389504
pose_goal.orientation.y = -0.3988517881317097
pose_goal.orientation.z = 0.23798648140067108
pose_goal.orientation.w = 0.18188254122047084
 
group.set_pose_target(pose_goal)
 
plan = group.go(wait=True)
group.stop()
group.clear_pose_targets()
rospy.loginfo("Motion complete")